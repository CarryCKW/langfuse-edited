export { VERSION } from "./VERSION";
